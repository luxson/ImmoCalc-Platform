import { Request, Response } from "express";
import { User } from "../models/user.model";

const clerkWebhookController = async (req: Request, res: Response) => {
    // Controller logic for handling Clerk webhooks
    try {
        // Extract event type and relevant data from the webhook payload
        const {type: eventType, data} = req.body; // The webhook payload sent by Clerk
        // Extract user details from the payload, handling cases where some details might be missing
        const {first_name, last_name, image_url} = data || {};
        const email = data.email_addresses?.[0]?.email_address || "No email provided";
        
        // Construct full name from first and last name, handling cases where one or both might be missing
        let fullName = "No name provided";
        if (first_name && last_name) {
            fullName = `${first_name} ${last_name}`;
        }else if (first_name) {
            fullName = first_name;
        } else if (last_name) {
            fullName = last_name;
        }

        // Handle different event types (e.g., user.created, user.updated, user.deleted)
        switch (eventType) {
            // Handle user creation event
            case "user.created":
                // Validate required user details
                const isUserDetailEmpty =  [email, fullName, image_url].some((field) => field.trim() === "" || field === "No email provided" || field === "No name provided");
                if (isUserDetailEmpty) {
                    return res.status(400).json({ error: "Missing required user details in webhook payload" });
                } 

                // Check if user already exists to prevent duplicates
                const existedUser = await User.findOne({ email });
                if (existedUser) {
                    return res.status(409).json({ message: "User already exists, skipping creation" });
                    break;
                }

                // Create a new user in the database
                const newUser = await User.create({
                    fullName,
                    email,
                    imageUrl: image_url,
                })
                // Check if user creation was successful
                if(!newUser) {
                    return res.status(500).json({ error: "Failed to create user" });
                }
                break;  
            case "user.updated":
                console.log(`User updated: ${fullName} (${email})`);
                break;
            case "user.deleted":
                console.log(`User deleted: ${fullName} (${email})`);
                break;
            default:
                return res.status(200).json({ error: `Unhandled event type: ${eventType} for user ${fullName} (${email})` });
        }
        // Respond with success message after processing the webhook
        return res.status(200).json({ message: "Webhook processed successfully" });
    } catch (error) {
        // Log the error and respond with an error message
        console.error("Error processing Clerk webhook:", error);
        return res.status(500).json({ error: "Internal Server Error" });
    }
}

export { clerkWebhookController };